class UnpopulatedPropertyError(Exception):
    pass


class UnknownGranteeTypeError(Exception):
    pass
